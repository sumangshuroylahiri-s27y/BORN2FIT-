'use client';

import Image from 'next/image';
import { motion } from 'motion/react';
import { Target, Users, Award, ShieldCheck } from 'lucide-react';

const features = [
  {
    icon: <Target className="w-6 h-6 text-red-600" />,
    title: 'Goal-Oriented Approach',
    description: 'We focus on your specific fitness goals, whether it\'s weight loss, muscle gain, or overall health.',
  },
  {
    icon: <Users className="w-6 h-6 text-red-600" />,
    title: 'Expert Trainers',
    description: 'Our certified professionals provide personalized guidance and motivation every step of the way.',
  },
  {
    icon: <Award className="w-6 h-6 text-red-600" />,
    title: 'Premium Equipment',
    description: 'Train with state-of-the-art machines and free weights designed for maximum results.',
  },
  {
    icon: <ShieldCheck className="w-6 h-6 text-red-600" />,
    title: 'Safe Environment',
    description: 'A clean, hygienic, and welcoming space where you can focus entirely on your workout.',
  },
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-zinc-950 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative z-10 rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl aspect-[4/3]">
              <Image
                src="https://images.unsplash.com/photo-1534258936925-c58bed479fcb?q=80&w=2070&auto=format&fit=crop"
                alt="Happy Gym Member"
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/80 to-transparent" />
            </div>
            {/* Decorative Elements */}
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-red-600/20 rounded-full blur-2xl z-0" />
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-red-700/20 rounded-full blur-2xl z-0" />
            
            <div className="absolute bottom-6 left-6 right-6 z-20 bg-zinc-900/90 backdrop-blur-md border border-zinc-800 p-6 rounded-xl">
              <p className="text-xl font-heading font-bold text-white mb-2">Our Mission</p>
              <p className="text-sm text-zinc-400 leading-relaxed">
                To empower the Newtown community through fitness, providing an environment where everyone feels supported, challenged, and inspired to reach their full potential.
              </p>
            </div>
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-sm font-bold text-red-600 uppercase tracking-widest mb-3">
              About BORN2FIT
            </h2>
            <h3 className="text-4xl md:text-5xl font-heading font-bold text-white mb-6 leading-tight">
              More Than Just A Gym. <br />
              <span className="text-zinc-500">It&apos;s A Lifestyle.</span>
            </h3>
            <p className="text-lg text-zinc-400 mb-10 leading-relaxed">
              Located in the heart of Newtown, Kolkata, BORN2FIT GYM was founded with a simple belief: fitness should be accessible, effective, and enjoyable. We&apos;ve built a community where beginners feel welcome and athletes feel challenged.
            </p>

            <div className="grid sm:grid-cols-2 gap-8">
              {features.map((feature, index) => (
                <div key={index} className="flex flex-col gap-3">
                  <div className="w-12 h-12 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                    {feature.icon}
                  </div>
                  <h4 className="text-lg font-bold text-white">{feature.title}</h4>
                  <p className="text-sm text-zinc-500 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
