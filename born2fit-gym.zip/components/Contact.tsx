'use client';

import { motion } from 'motion/react';
import { MapPin, Phone, Clock, Mail, Send } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-zinc-950 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-sm font-bold text-red-600 uppercase tracking-widest mb-3">
              Get In Touch
            </h2>
            <h3 className="text-4xl md:text-5xl font-heading font-bold text-white mb-6 leading-tight">
              Ready To Start? <br />
              <span className="text-zinc-500">Contact Us Today.</span>
            </h3>
            <p className="text-lg text-zinc-400 mb-10 leading-relaxed">
              Drop by our gym in Newtown or send us a message. We&apos;re here to answer any questions and help you begin your fitness journey.
            </p>

            <div className="space-y-8 mb-12">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Location</h4>
                  <p className="text-zinc-400 leading-relaxed">
                    Office Top Floor, BORN2FIT(GYM)<br />
                    Gourangonagar post, Sulanggari, Hatiara<br />
                    Newtown, Kolkata, Ghuni, West Bengal 700162
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                  <Phone className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Phone</h4>
                  <p className="text-zinc-400 leading-relaxed">
                    <a href="tel:+919876543210" className="hover:text-red-600 transition-colors">+91 98765 43210</a>
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                  <Mail className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Email</h4>
                  <p className="text-zinc-400 leading-relaxed">
                    <a href="mailto:info@born2fitgym.com" className="hover:text-red-600 transition-colors">info@born2fitgym.com</a>
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Hours</h4>
                  <p className="text-zinc-400 leading-relaxed">
                    Monday - Saturday: 6:00 AM - 10:00 PM<br />
                    Sunday: 7:00 AM - 12:00 PM
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact Form & Map */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-8"
          >
            <form className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 shadow-2xl">
              <h4 className="text-2xl font-bold text-white mb-6">Send a Message</h4>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-zinc-400 mb-1">First Name</label>
                    <input type="text" id="firstName" className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-600 transition-colors" placeholder="John" />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-zinc-400 mb-1">Last Name</label>
                    <input type="text" id="lastName" className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-600 transition-colors" placeholder="Doe" />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-zinc-400 mb-1">Email Address</label>
                    <input type="email" id="email" className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-600 transition-colors" placeholder="john@example.com" />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-zinc-400 mb-1">Phone Number</label>
                    <input type="tel" id="phone" className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-600 transition-colors" placeholder="+91 98765 43210" />
                  </div>
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-zinc-400 mb-1">Message</label>
                  <textarea id="message" rows={4} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-600 transition-colors" placeholder="How can we help you?"></textarea>
                </div>
                <button type="button" className="w-full bg-red-600 text-white font-bold rounded-lg px-4 py-4 hover:bg-red-700 transition-colors flex items-center justify-center gap-2">
                  Send Message
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </form>

            <div className="h-[300px] rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3683.693121542456!2d88.4659!3d22.5891!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a02756b767c7695%3A0xac36dc951f9f9fdb!2sBORN2FIT(GYM)%20%7C%20Best%20Gym%20Near%20Newtown!5e0!3m2!1sen!2sin!4v1710000000000!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="BORN2FIT GYM Location"
                className="grayscale opacity-80 hover:grayscale-0 hover:opacity-100 transition-all duration-500"
              ></iframe>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
