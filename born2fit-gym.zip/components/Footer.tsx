import { Dumbbell, Facebook, Instagram, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-zinc-950 border-t border-zinc-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div className="md:col-span-2">
            <a href="#home" className="flex items-center gap-2 group mb-6">
              <div className="bg-red-600 p-2 rounded-lg text-white group-hover:bg-red-700 transition-colors">
                <Dumbbell size={24} strokeWidth={2.5} />
              </div>
              <span className="font-heading font-bold text-2xl tracking-tight text-white">
                BORN2FIT
              </span>
            </a>
            <p className="text-zinc-400 leading-relaxed max-w-sm mb-6">
              Newtown&apos;s premier fitness destination. We provide the equipment, expertise, and community you need to transform your life.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-red-600 hover:border-red-600 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-red-600 hover:border-red-600 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-red-600 hover:border-red-600 transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#home" className="text-zinc-400 hover:text-red-600 transition-colors">Home</a></li>
              <li><a href="#about" className="text-zinc-400 hover:text-red-600 transition-colors">About Us</a></li>
              <li><a href="#services" className="text-zinc-400 hover:text-red-600 transition-colors">Services</a></li>
              <li><a href="#why-us" className="text-zinc-400 hover:text-red-600 transition-colors">Why Choose Us</a></li>
              <li><a href="#reviews" className="text-zinc-400 hover:text-red-600 transition-colors">Reviews</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Services</h4>
            <ul className="space-y-4">
              <li><a href="#services" className="text-zinc-400 hover:text-red-600 transition-colors">Personal Training</a></li>
              <li><a href="#services" className="text-zinc-400 hover:text-red-600 transition-colors">Strength Training</a></li>
              <li><a href="#services" className="text-zinc-400 hover:text-red-600 transition-colors">Cardio Fitness</a></li>
              <li><a href="#services" className="text-zinc-400 hover:text-red-600 transition-colors">Weight Loss</a></li>
              <li><a href="#services" className="text-zinc-400 hover:text-red-600 transition-colors">Group Classes</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-zinc-500 text-sm">
            &copy; {new Date().getFullYear()} BORN2FIT GYM. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-zinc-500 hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="text-zinc-500 hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
