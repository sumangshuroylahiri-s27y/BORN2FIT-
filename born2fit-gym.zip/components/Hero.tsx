'use client';

import Image from 'next/image';
import { motion } from 'motion/react';
import { ArrowRight, Play } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-zinc-950 pt-20">
      {/* Background Image & Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent z-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent z-10" />
        <Image
          src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=2070&auto=format&fit=crop"
          alt="Friendly Gym Environment"
          fill
          className="object-cover opacity-40"
          referrerPolicy="no-referrer"
          priority
        />
      </div>

      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex flex-col md:flex-row items-center">
        <div className="w-full md:w-2/3 lg:w-1/2 pt-12 pb-20 md:py-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900/80 border border-zinc-800 backdrop-blur-sm mb-6"
          >
            <span className="flex h-2 w-2 rounded-full bg-red-600 animate-pulse" />
            <span className="text-xs font-medium text-zinc-300 uppercase tracking-wider">
              Voted Best Gym Near Newtown
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl md:text-6xl lg:text-7xl font-heading font-bold text-white leading-[1.1] mb-6"
          >
            Transform Your <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-700">
              Life & Body
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-zinc-400 mb-10 max-w-lg leading-relaxed"
          >
            Join BORN2FIT GYM, Newtown&apos;s premier fitness destination. Expert trainers, state-of-the-art equipment, and a community that pushes you to be your best.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center gap-4"
          >
            <a
              href="#contact"
              className="w-full sm:w-auto px-8 py-4 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 transition-all flex items-center justify-center gap-2 group hover:shadow-[0_0_30px_rgba(220,38,38,0.4)]"
            >
              Start Your Journey
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="#services"
              className="w-full sm:w-auto px-8 py-4 bg-transparent text-white font-semibold rounded-lg border border-zinc-700 hover:bg-zinc-800 transition-colors flex items-center justify-center gap-2"
            >
              <Play size={20} className="text-red-600" />
              Explore Services
            </a>
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-16 grid grid-cols-3 gap-6 pt-8 border-t border-zinc-800/50"
          >
            <div>
              <p className="text-3xl font-heading font-bold text-white mb-1">4.9<span className="text-red-600 text-xl">★</span></p>
              <p className="text-sm text-zinc-500 font-medium">Google Rating</p>
            </div>
            <div>
              <p className="text-3xl font-heading font-bold text-white mb-1">150<span className="text-red-600">+</span></p>
              <p className="text-sm text-zinc-500 font-medium">Happy Members</p>
            </div>
            <div>
              <p className="text-3xl font-heading font-bold text-white mb-1">24<span className="text-red-600">/</span>7</p>
              <p className="text-sm text-zinc-500 font-medium">Support</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
