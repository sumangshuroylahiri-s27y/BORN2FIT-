'use client';

import { motion } from 'motion/react';
import { Dumbbell, Activity, HeartPulse, Flame, Zap, ArrowRight } from 'lucide-react';

const services = [
  {
    icon: <Dumbbell className="w-8 h-8 text-red-600" />,
    title: 'Strength Training',
    description: 'Build muscle, increase power, and sculpt your physique with our comprehensive free weights and resistance machines.',
  },
  {
    icon: <Activity className="w-8 h-8 text-red-600" />,
    title: 'Personal Training',
    description: 'Get 1-on-1 guidance from certified experts who design custom workout plans tailored to your specific goals.',
  },
  {
    icon: <HeartPulse className="w-8 h-8 text-red-600" />,
    title: 'Cardio Fitness',
    description: 'Improve endurance and heart health with our top-tier treadmills, ellipticals, and stationary bikes.',
  },
  {
    icon: <Flame className="w-8 h-8 text-red-600" />,
    title: 'Weight Loss Programs',
    description: 'Structured routines combining HIIT, cardio, and nutrition advice to help you shed pounds effectively.',
  },
  {
    icon: <Zap className="w-8 h-8 text-red-600" />,
    title: 'CrossFit & Functional',
    description: 'High-intensity functional movements designed to improve overall athletic performance and agility.',
  },
  {
    icon: <Dumbbell className="w-8 h-8 text-red-600" />,
    title: 'Group Classes',
    description: 'Join our energetic group sessions including Zumba, Yoga, and Aerobics for a fun, community-driven workout.',
  },
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-zinc-900 border-t border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-bold text-red-600 uppercase tracking-widest mb-3"
          >
            Our Services
          </motion.h2>
          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-heading font-bold text-white mb-6 leading-tight"
          >
            Everything You Need To <br />
            <span className="text-zinc-500">Reach Your Goals</span>
          </motion.h3>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-zinc-400 leading-relaxed"
          >
            From specialized equipment to expert coaching, BORN2FIT provides a comprehensive fitness experience tailored for all levels.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group bg-zinc-950 border border-zinc-800 rounded-2xl p-8 hover:border-red-600/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(220,38,38,0.1)]"
            >
              <div className="w-16 h-16 rounded-xl bg-zinc-900 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h4 className="text-xl font-bold text-white mb-4">{service.title}</h4>
              <p className="text-zinc-400 leading-relaxed mb-6">
                {service.description}
              </p>
              <a href="#contact" className="inline-flex items-center text-sm font-bold text-red-600 hover:text-red-500 transition-colors group/link">
                Learn More
                <ArrowRight className="ml-2 w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
