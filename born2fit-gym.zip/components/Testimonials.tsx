'use client';

import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Rahul Sharma',
    role: 'Member since 2023',
    content: 'Hands down the best gym near Newtown! The trainers are incredibly knowledgeable and genuinely care about your progress. The equipment is top-notch and the environment is super motivating.',
    rating: 5,
  },
  {
    name: 'Priya Das',
    role: 'Member since 2024',
    content: 'I joined BORN2FIT for their weight loss program and the results have been amazing. The community here is so supportive. It feels less like a gym and more like a fitness family.',
    rating: 5,
  },
  {
    name: 'Amit Kumar',
    role: 'Member since 2022',
    content: 'Great location, affordable pricing, and excellent facilities. Whether you are into heavy lifting or cardio, they have everything you need. Highly recommend to anyone in Kolkata.',
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section id="reviews" className="py-24 bg-zinc-900 border-t border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-bold text-red-600 uppercase tracking-widest mb-3"
          >
            Client Success Stories
          </motion.h2>
          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-heading font-bold text-white mb-6 leading-tight"
          >
            Don&apos;t Just Take <br />
            <span className="text-zinc-500">Our Word For It</span>
          </motion.h3>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-zinc-400 leading-relaxed"
          >
            See what our members have to say about their transformations and experience at BORN2FIT GYM.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-zinc-950 border border-zinc-800 rounded-2xl p-8 relative"
            >
              <Quote className="absolute top-6 right-6 w-12 h-12 text-zinc-800 opacity-50" />
              
              <div className="flex gap-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-red-600 text-red-600" />
                ))}
              </div>
              
              <p className="text-zinc-300 leading-relaxed mb-8 italic">
                &quot;{testimonial.content}&quot;
              </p>
              
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-zinc-800 rounded-full flex items-center justify-center text-xl font-bold text-red-600">
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-white font-bold">{testimonial.name}</h4>
                  <p className="text-sm text-zinc-500">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
