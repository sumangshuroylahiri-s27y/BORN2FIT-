'use client';

import Image from 'next/image';
import { motion } from 'motion/react';
import { CheckCircle2, MapPin, Star, Trophy } from 'lucide-react';

const reasons = [
  {
    icon: <Trophy className="w-6 h-6 text-red-600" />,
    title: 'Voted Best Gym Near Newtown',
    description: 'Recognized for our exceptional facilities, expert trainers, and vibrant fitness community.',
  },
  {
    icon: <Star className="w-6 h-6 text-red-600" />,
    title: '4.9/5 Google Rating',
    description: 'Over 150+ happy members trust us with their fitness journey. Our results speak for themselves.',
  },
  {
    icon: <MapPin className="w-6 h-6 text-red-600" />,
    title: 'Prime Location',
    description: 'Conveniently located at Gourangonagar post, Sulanggari, Hatiara, Newtown, Kolkata.',
  },
  {
    icon: <CheckCircle2 className="w-6 h-6 text-red-600" />,
    title: 'Affordable Memberships',
    description: 'Premium fitness experience without the premium price tag. Flexible plans for everyone.',
  },
];

export default function WhyChooseUs() {
  return (
    <section id="why-us" className="py-24 bg-zinc-950 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-sm font-bold text-red-600 uppercase tracking-widest mb-3">
              Why Choose Us
            </h2>
            <h3 className="text-4xl md:text-5xl font-heading font-bold text-white mb-6 leading-tight">
              The BORN2FIT <br />
              <span className="text-zinc-500">Advantage</span>
            </h3>
            <p className="text-lg text-zinc-400 mb-10 leading-relaxed">
              We don&apos;t just offer equipment; we offer a complete fitness ecosystem designed to guarantee results. Here&apos;s why we are the top choice for fitness enthusiasts in Newtown.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              {reasons.map((reason, index) => (
                <div key={index} className="flex flex-col gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                    {reason.icon}
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white mb-2">{reason.title}</h4>
                    <p className="text-zinc-400 leading-relaxed text-sm">
                      {reason.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative h-[600px] rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl"
          >
            <Image
              src="https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=2070&auto=format&fit=crop"
              alt="Modern Gym Facility"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
            
            {/* Floating Badge */}
            <div className="absolute bottom-8 left-8 right-8 bg-zinc-900/90 backdrop-blur-md border border-zinc-800 p-6 rounded-xl flex items-center gap-4">
              <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-2xl font-bold text-white">100%</span>
              </div>
              <div>
                <p className="text-lg font-bold text-white">Commitment to Results</p>
                <p className="text-sm text-zinc-400">Your success is our priority.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
