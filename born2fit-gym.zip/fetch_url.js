const https = require('https');
https.get('https://maps.app.goo.gl/khmGGqqRff7MVMCM7', (res) => {
  console.log(res.headers.location);
});
